<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
    <h1>site-personnel-fl.local</h1>
    <p>Vous consultez cette page depuis l'adresse <strong><?= $_SERVER['REMOTE_ADDR'] ?></strong></p>
    </body>
</html>
