<?php include "Page_d_accueil.php"; ?>
<p></p>
<?php include "A_propos.php"; ?>
<p></p>
<?php include "Compétences.php"; ?>
<p></p>
<?php include "Expérience.php"; ?>
<p></p>
<?php include "Formation.php"; ?>
<p></p>
<?php include "Contact.php"; ?>
