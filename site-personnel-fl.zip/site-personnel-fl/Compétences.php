<body>
<div id="Compétences"></div>
<div class="body_Compétences">

<p class="titre_page">Compétences</b></p>

<table class="table_page">
  <tr class="tableau_page_Compétences">
    <td class="tableau_page4_Compétences"><b>Informatique et technique</b></td>
  </tr>
</table>

<table class="table_page">

  <tr class="tableau_page_Compétences">
    <td class="tableau_page_Compétences">A l'aise ++</td>
    <td class="tableau_page_Compétences">A l'aise +</td>
    <td class="tableau_page_Compétences">En cours de pratique</td>
  </tr>

  <tr class="tableau_page_Compétences">
    <td class="tableau_page2_Compétences"><progress id="file" max="100" value="100"> 100% </progress></td>
    <td class="tableau_page2_Compétences"><progress id="file" max="100" value="60"> 60% </progress></td>
    <td class="tableau_page2_Compétences"><progress id="file" max="100" value="25"> 25% </progress></td>
  </tr>

  <tr>
    <td class="tableau_page3_Compétences">&bull; Adobe Photoshop <br>&bull; Adobe Premiere</td>
    <td class="tableau_page3_Compétences">&bull; Labview <br>&bull; Arduino <br>&bull; Html/css <br>&bull; PacketTracer</td>
    <td class="tableau_page3_Compétences">&bull; php <br>&bull; Apache <br>&bull; Python</td>
  </tr>

</table>

<table class="table_page">
  <tr class="tableau_page_Compétences">
    <td class="tableau_page4_Compétences"><b>Langues</b></td>
  </tr>
</table>

<table class="table_page">

  <tr class="tableau_page_Compétences">
    <td class="tableau_page_Compétences">A l'aise ++</td>
    <td class="tableau_page_Compétences">A l'aise +</td>
    <td class="tableau_page_Compétences">En cours de pratique</td>
  </tr>

  <tr class="tableau_page_Compétences">
    <td class="tableau_page2_Compétences"><progress id="file" max="100" value="100"> 100% </progress></td>
    <td class="tableau_page2_Compétences"><progress id="file" max="100" value="60"> 60% </progress></td>
    <td class="tableau_page2_Compétences"><progress id="file" max="100" value="25"> 25% </progress></td>
  </tr>

  <tr class="tableau_page_Compétences">
    <td class="tableau_page3_Compétences"></td>
    <td class="tableau_page3_Compétences">&bull; Anglais</td>
    <td class="tableau_page3_Compétences">&bull; Espagnol</td>
  </tr>

</table>

<div>
<a href="#Expérience" class="flèche"><i class="fas fa-angle-down"></i></a>
</div>

</div>
</body>
