<body>
<div id="A_propos"></div>
<div class="body_A_propos">

<p class="titre_page">Louka Fauvel</p>

<p class="accroche_page_A_propos">Sérieux et collectif</p>

<p class="texte_page_A_propos">Je suis élève en première année de BTS Service informatique aux organisations
au pôle SupAvenir Sainte Ursule de Caen en Normandie. J'aime beaucoup voyager
et découvrir de nouvelles traditions culturelles. J'ai eu la chance de participer
J'ai eu la chance de participer à deux échanges Erasmus avec la Suède et l'Espagne
en 2019. Je fais du dessin à l'Esam de Caen et je pratique le théâtre depuis l'âge
de 7 ans. Je suis un élève sérieux qui aime travailler en équipe sur de nouveaux
projets.</p>

<img class="image_page_A_propos" src="image/Louka_Fauvel.png">

<div>
<a href="#Compétences" class="flèche"><i class="fas fa-angle-down"></i></a>
</div>

</div>
</body>
